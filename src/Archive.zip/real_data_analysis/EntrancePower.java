package real_data_analysis;

/*
 * Given genotype stored in the hdf5 formats, assign phenotype 
 */
public class EntrancePower {
	public static void main(String[] args) {
		EntranceSim.have_a_look();
	}
}
