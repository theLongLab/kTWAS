package myPlotLab;

public class MyBoxPlot {

}
